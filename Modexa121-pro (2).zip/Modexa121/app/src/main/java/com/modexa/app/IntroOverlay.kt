package com.modexa.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.sin

private const val ACCENT = 0xFF5EEAD4.toInt()
private const val ACCENT2 = 0xFFA78BFA.toInt()
private const val BG = 0xFF0B0F1A.toInt()
private const val TEXT = 0xFFE6EDF7.toInt()
private const val MUTED = 0xFF8B97AD.toInt()

/** Animated equalizer logo (same bars as the in-app launcher button). */
class EqualizerView(context: Context) : View(context) {
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val base = floatArrayOf(0.55f, 1f, 0.8f, 0.45f)
    private var phase = 0f
    private var appear = 0f
    var showRing = false
    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private val intro = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 700
        interpolator = OvershootInterpolator(1.6f)
        addUpdateListener { appear = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        loop.start(); intro.start()
    }

    override fun onDetachedFromWindow() {
        loop.cancel(); intro.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val cx = w / 2f; val cy = h / 2f
        val pulse = 0.5f + 0.5f * sin(phase * 2f * PI.toFloat())
        val r = w * (0.42f + 0.06f * pulse) * appear
        glow.shader = RadialGradient(cx, cy, r.coerceAtLeast(1f),
            intArrayOf(0x405EEAD4, 0x00000000), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, glow)
        if (showRing) {
            val t = phase
            ring.strokeWidth = w * 0.012f
            ring.color = Color.argb(((1f - t) * 140).toInt(), 94, 234, 212)
            c.drawCircle(cx, cy, w * (0.30f + 0.20f * t), ring)
        }
        val n = base.size
        val bw = w * 0.085f; val gap = w * 0.055f
        val total = n * bw + (n - 1) * gap
        var x = cx - total / 2f
        val maxH = h * 0.5f
        for (i in 0 until n) {
            val wave = 0.5f + 0.5f * sin((phase + i * 0.22f) * 2f * PI.toFloat())
            val bh = (base[i] * (0.45f + 0.55f * wave)) * maxH * appear
            rect.set(x, cy - bh / 2f, x + bw, cy + bh / 2f)
            bar.shader = android.graphics.LinearGradient(0f, rect.top, 0f, rect.bottom, ACCENT, ACCENT2, Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, bar)
            x += bw + gap
        }
    }
}

/**
 * Full-screen Modexá intro: animated splash on every launch,
 * plus a 3-page onboarding the first time the app is opened.
 */
class IntroOverlay(
    context: Context,
    private val showOnboarding: Boolean,
    private val onFinished: () -> Unit
) : FrameLayout(context) {

    private data class Page(val title: String, val body: String, val kind: Int)

    private val pages = listOf(
        Page("Welcome to Modexá", "Studio-grade mic processing for Discord voice. Clean, loud and clear.", 0),
        Page("Your panel, one tap away", "Tap the equalizer button to open the panel. Drag the header to move it anywhere.", 1),
        Page("Allow your microphone", "Modexá needs the mic and notifications to keep your voice call alive in the background.", 2)
    )

    private var index = 0
    private var finished = false
    private val content = FrameLayout(context)
    private val dots = LinearLayout(context)
    private val next = TextView(context)
    private val skip = TextView(context)
    private val splash = FrameLayout(context)
    private var onboardingActive = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setBackgroundColor(BG)
        isClickable = true
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(BG, 0xFF1B1340.toInt()))
        buildSplash()
        addView(splash, LayoutParams(-1, -1))
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
    }

    private fun buildSplash() {
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val eq = EqualizerView(context)
        col.addView(eq, LinearLayout.LayoutParams(dp(150), dp(150)))
        val title = label("MODEXÁ", 28f, TEXT, true).apply { letterSpacing = 0.25f; alpha = 0f; translationY = dp(12).toFloat() }
        val sub = label("121", 14f, ACCENT, true).apply { letterSpacing = 0.5f; alpha = 0f; translationY = dp(12).toFloat() }
        col.addView(title, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        col.addView(sub, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        splash.addView(col, LayoutParams(-2, -2, Gravity.CENTER))
        title.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(600)
            .setInterpolator(DecelerateInterpolator()).start()
        sub.animate().alpha(1f).translationY(0f).setStartDelay(550).setDuration(600)
            .setInterpolator(DecelerateInterpolator()).start()
        // splash lasts ~1.7s, then onboarding (first run) or finish
        postDelayed({ if (showOnboarding) startOnboarding() else finish() }, 1700)
    }

    private fun startOnboarding() {
        if (finished) return
        onboardingActive = true
        splash.animate().alpha(0f).setDuration(350).withEndAction { splash.visibility = GONE }.start()

        addView(content, LayoutParams(-1, -1))

        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER
        val bottom = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bottom.addView(dots, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(20) })

        next.apply {
            gravity = Gravity.CENTER
            textSize = 16f
            setTextColor(BG)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(ACCENT, ACCENT2)).apply { cornerRadius = dp(28).toFloat() }
            setOnClickListener { goNext() }
        }
        bottom.addView(next, LinearLayout.LayoutParams(dp(240), dp(54)))

        skip.apply {
            text = "Skip"
            textSize = 14f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { finish() }
        }
        bottom.addView(skip, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })

        addView(bottom, LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(32) })

        bottom.alpha = 0f
        bottom.animate().alpha(1f).setStartDelay(250).setDuration(450).start()
        showPage(0, forward = true, first = true)
    }

    private fun goNext() {
        if (index < pages.lastIndex) showPage(index + 1, forward = true) else finish()
    }

    /** Back press during onboarding: previous page. Returns true if consumed. */
    fun handleBack(): Boolean {
        if (finished) return false
        if (onboardingActive && index > 0) { showPage(index - 1, forward = false); return true }
        return true // swallow back while the intro is showing
    }

    private fun showPage(i: Int, forward: Boolean, first: Boolean = false) {
        val old = if (content.childCount > 0) content.getChildAt(0) else null
        index = i
        val page = pages[i]
        val v = buildPage(page)
        content.addView(v, LayoutParams(-1, -1))
        val dir = if (forward) 1 else -1
        val dx = dp(70) * dir
        if (!first) {
            v.alpha = 0f; v.translationX = dx.toFloat()
            v.animate().alpha(1f).translationX(0f).setDuration(420).setInterpolator(DecelerateInterpolator(2f)).start()
        } else {
            v.alpha = 0f
            v.animate().alpha(1f).setStartDelay(300).setDuration(500).start()
        }
        old?.animate()?.alpha(0f)?.translationX(-dx.toFloat())?.setDuration(300)
            ?.setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { content.removeView(old) }
            })?.start()
        next.text = if (i == pages.lastIndex) "Get started" else "Next"
        skip.visibility = if (i == pages.lastIndex) INVISIBLE else VISIBLE
        updateDots()
    }

    private fun updateDots() {
        dots.removeAllViews()
        pages.indices.forEach { n ->
            val active = n == index
            val d = View(context).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(4).toFloat()
                    setColor(if (active) ACCENT else 0x40FFFFFF)
                }
            }
            val lp = LinearLayout.LayoutParams(dp(if (active) 22 else 8), dp(8)).apply { marginStart = dp(4); marginEnd = dp(4) }
            dots.addView(d, lp)
        }
    }

    private fun buildPage(p: Page): View {
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), dp(90), dp(32), dp(190))
        }
        val art: View = when (p.kind) {
            0 -> EqualizerView(context)
            1 -> EqualizerView(context).apply { showRing = true }
            else -> micArt()
        }
        col.addView(art, LinearLayout.LayoutParams(dp(190), dp(190)))
        col.addView(label(p.title, 24f, TEXT, true), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(36) })
        col.addView(label(p.body, 15f, MUTED).apply { setLineSpacing(0f, 1.2f) },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        return col
    }

    private fun micArt(): View {
        val box = FrameLayout(context)
        val ringV = object : View(context) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
            private var t = 0f
            private val an = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1600; repeatCount = ValueAnimator.INFINITE
                addUpdateListener { t = it.animatedValue as Float; invalidate() }
            }
            override fun onAttachedToWindow() { super.onAttachedToWindow(); an.start() }
            override fun onDetachedFromWindow() { an.cancel(); super.onDetachedFromWindow() }
            override fun onDraw(c: Canvas) {
                paint.strokeWidth = width * 0.012f
                paint.color = Color.argb(((1f - t) * 150).toInt(), 94, 234, 212)
                c.drawCircle(width / 2f, height / 2f, width * (0.28f + 0.22f * t), paint)
            }
        }
        box.addView(ringV, LayoutParams(-1, -1))
        val disc = FrameLayout(context).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(ACCENT, ACCENT2)).apply { shape = GradientDrawable.OVAL }
        }
        val mic = ImageView(context).apply {
            setImageResource(R.drawable.ic_notif)
            setColorFilter(BG)
        }
        disc.addView(mic, LayoutParams(dp(44), dp(44), Gravity.CENTER))
        box.addView(disc, LayoutParams(dp(92), dp(92), Gravity.CENTER))
        disc.scaleX = 0.6f; disc.scaleY = 0.6f
        disc.animate().scaleX(1f).scaleY(1f).setStartDelay(150).setDuration(600)
            .setInterpolator(OvershootInterpolator(2f)).start()
        return box
    }

    private fun finish() {
        if (finished) return
        finished = true
        animate().alpha(0f).setDuration(450).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onFinished()
        }.start()
    }
}
